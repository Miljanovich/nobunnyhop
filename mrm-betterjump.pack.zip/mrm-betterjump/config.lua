--GitHub.com/░█▀▄▀█ █▀▀█ ░█▀▄▀█ ░█▀▀█ ░█──░█ ░█─── ░█▀▀▀█-- 
--------─────░█░█░█ █▄▄▀ ░█░█░█ ░█▄▄▀ ─░█░█─ ░█─── ─▀▀▀▄▄-- 
---────---──-░█──░█ ▀─▀▀ ░█──░█ ░█─░█ ──▀▄▀─ ░█▄▄█ ░█▄▄▄█--
--──-----──---------────-------──---──────-----------------

Config = {}

-- 🕺🏽 Better Jump Limit; default 15
Config.jumpLimit = 15 -- higher the value → players can jump more

-- fall effect ✨
Config.fallEffect = true