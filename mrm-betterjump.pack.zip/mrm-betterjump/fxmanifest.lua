fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'MrMRVLS'
description 'No more Bunny Hopping.'
version '1.0.0'

client_script {
  'client/client.lua',
}

server_scripts {
  'server/Resourcename.lua',
}

shared_script {
  'config.lua',
}

escrow_ignore {
    'config.lua',
    'README.md',
  }
dependency '/assetpacks'